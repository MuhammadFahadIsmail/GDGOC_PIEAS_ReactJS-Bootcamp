import React from 'react';
import HighRatedBooks from './HighRatedBooks';
import BookDetails from './BookDetails';
import FictionBooks from './FictionBooks';
import BookAuthors from './BookAuthors';

const App = () => (
  <div style={{
    textAlign: "center"}}>
    <h1>Library Manager</h1>
    <HighRatedBooks />
    <BookDetails />
    <FictionBooks />
    <BookAuthors />
  </div>
);

export default App;
