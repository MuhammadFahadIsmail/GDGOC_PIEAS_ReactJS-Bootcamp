import React from 'react';
import PropTypes from 'prop-types';

const BookCard = ({ title, author, rating, genre }) => (
  <div>
    <h2>{title}</h2>
    <p>Author: {author}</p>
    <p>Rating: {rating}</p>
    <p>Genre: {genre}</p>
  </div>
);

BookCard.propTypes = {
  title: PropTypes.string.isRequired,
  author: PropTypes.string.isRequired,
  rating: PropTypes.number.isRequired,
  genre: PropTypes.string.isRequired,
};

export default BookCard;
